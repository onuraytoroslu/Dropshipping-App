import java.io.*;

public class FileIO {	
	
	public static String[] customers = new String[0];
	public static String[] s1_products = new String[0];
	public static String[] s1_sales = new String[0];
	public static String[] s2_products = new String[0];
	public static String[] s2_sales = new String[0];
	public static String[] s3_products = new String[0];
	public static String[] s3_sales = new String[0];
	
	
	public static void ScanData() throws Exception {
		BufferedReader r1 = new BufferedReader(new FileReader("Customers.csv"));
		BufferedReader r2 = new BufferedReader(new FileReader("S1_Products.csv"));
		BufferedReader r3 = new BufferedReader(new FileReader("S1_Sales.csv"));
		BufferedReader r4 = new BufferedReader(new FileReader("S2_Products.csv"));
		BufferedReader r5 = new BufferedReader(new FileReader("S2_Sales.csv"));
		BufferedReader r6 = new BufferedReader(new FileReader("S3_Products.csv"));
		BufferedReader r7 = new BufferedReader(new FileReader("S3_Sales.csv"));
		
		
		String line = null;
		while ((line = r1.readLine()) != null) {
		    customers = add(customers, line);}
		customers = removeFirstIndex(customers);
		
		
		while ((line = r2.readLine()) != null) {
		    s1_products = add(s1_products, line);}
		s1_products = removeFirstIndex(s1_products);
		
		
		while ((line = r3.readLine()) != null) {
		    s1_sales = add(s1_sales, line);}
		s1_sales = removeFirstIndex(s1_sales);
		
		
		while ((line = r4.readLine()) != null) {
		    s2_products = add(s2_products, line);}
		s2_products = removeFirstIndex(s2_products);
		
		
		while ((line = r5.readLine()) != null) {
		    s2_sales = add(s2_sales, line);}
		s2_sales = removeFirstIndex(s2_sales);
		
		
		while ((line = r6.readLine()) != null) {
		    s3_products = add(s3_products, line);}
		s3_products = removeFirstIndex(s3_products);
		
		
		while ((line = r7.readLine()) != null) {
		    s3_sales = add(s3_sales, line);}
		s3_sales = removeFirstIndex(s3_sales);
		
		
	r1.close();
	r2.close();
	r3.close();
	r4.close();
	r5.close();
	r6.close();
	r7.close();
}
	

	private static String[] add(String[] strings, String newStr ) {
		String[] result = new String[strings.length +1];
		int index = 0;
		for(String str: strings) {
			result[index] = str;
			index++;
		}
		result[index] = newStr;
		return result;}
	
	
	private static String[] removeFirstIndex(String[] strings) {
		String[] result = new String[strings.length - 1];
		for (int i = 1; i < strings.length; i++) {
			result[i-1] = strings[i];
		}
		return result;}
	
	}
	