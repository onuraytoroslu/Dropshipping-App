
public class SalesQuery {

	/*1- The most profitable product among the three suppliers. (Please include the amount of 
			profit to output.)
			2- The most expensive product in terms of Sales Price. (Please include the amount of Sales 
			Price to output.)
			3- The customer who purchases the most products for all three suppliers. (Please include the 
			number of purchases to output.)
			4- The total profit that is made from all sales.
			5- The least-profit product of S1. (Please include the amount of profit to output.) */
	
	
}
