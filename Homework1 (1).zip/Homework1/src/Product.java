
public class Product {

	private String id;
	private String title;
	private double rate;
	private int numberOfReviews;
	private int price;
	
	
	public Product() {
	
	}
	
	public Product(String id, String title, double rate, int numberOfReviews, int price) {
		this.id = id;
		this.title = title;
		this.rate = rate;
		this.numberOfReviews = numberOfReviews;
		this.price = price;
		
	}
	
	public String getID() {
		
		return id;
	}
	
	public String getTitle() {
		
		return title;
	}
	
	public double getRate() {
		
		return rate;
	}
	
	public int getNumberOfReviews() {
		
		return numberOfReviews;
	}
	
	public int getPrice() {
		
		return price;
	}
	
}
