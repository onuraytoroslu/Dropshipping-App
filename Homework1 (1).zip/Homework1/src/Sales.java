import java.util.Date;

public class Sales {

	private int id;
	private String customer;
	private String product;
	private Date salesDate;
	private double salesPrice;
	
	public Sales() {
		
	}
	
	public Sales(int id, String customer, String product, Date salesDate, int salesPrice) {
		
		this.id = id;
		this.customer = customer;
		this.product = product;
		this.salesDate = salesDate;
		this.salesPrice = salesPrice;
		
	}
	
	public int getID() {
		
		return id;
	}
	
	public String getCustomer() {
		
		return customer;
	}
	
	public String product() {
		
		return product;
	}
	
	public Date getSalesDate() {
		
		return new Date(salesDate.getTime());
	}
	
	public double getSalesPrice() {
		
		return salesPrice;
	}
	
	public double calculateSalesPrice(int price, double rate, int numberOfReviews) {
		
		double salesPrice = price + rate*20*numberOfReviews;
		this.salesPrice = salesPrice;
		return this.salesPrice;
	}
	
}