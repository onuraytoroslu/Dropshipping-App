
public class DropshippingApp {

	public static void main(String[] args) throws Exception {
		
		FileIO.ScanData();
		Supplier.SupplyProducts();

		

	}

}
