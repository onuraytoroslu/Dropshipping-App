
public class Supplier {

	public static Product[] products = new Product[0];
	
	
	public static void SupplyProducts() {
		
		String[] data = new String[5];
		for (String s: FileIO.s1_products) {
			data = s.split(",");
			inputData(data);
		}
		
		for (String s: FileIO.s2_products) {
			data = s.split(",");
			inputData(data);
			
		}
		
		for(String s: FileIO.s3_products) {
			data = s.split(",");
			inputData(data);
		}
		
		/* deneme, silinecek*/
	int index = 1;
	for (Product prod: products) {
		System.out.println("PROD " + index + " ID: " +prod.getID() + " TITLE: " + prod.getTitle() + " RATE: "
	+ prod.getRate() + " NoR: " + prod.getNumberOfReviews() + " PRICE: " + prod.getPrice());
		index++;
	}
		/* deneme, silinecek*/
	
	
	
	}
	
	
	private static void inputData(String[] data) {
		double rate = Double.parseDouble(data[2]);
		int numberOfReviews = Integer.parseInt(data[3]);
		int price = Integer.parseInt(data[4]);
		Product newProduct = new Product(data[0], data[1], rate, numberOfReviews, price);
		products = addProduct(products, newProduct);
		
	}
	
	
	private static Product[] addProduct(Product[] allProducts, Product newProduct) {
		
		Product[] result = new Product[allProducts.length + 1];
		
		int index = 0;
		for(Product prod: allProducts) {
			result[index] = prod;
			index++;
		}
		result[index] = newProduct;
		return result;}
	
}
