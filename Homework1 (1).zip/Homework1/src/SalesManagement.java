
public class SalesManagement {
 /* Sales
	✓ Note: Two-dimensional array that holds Sales objects for each Supplier. 
	✓ Ex: For 3rd supplier’s 7th Sales, it is [2][6].
 	Implement necessary methods to respond the following queries in SalesQuery class: */
}
